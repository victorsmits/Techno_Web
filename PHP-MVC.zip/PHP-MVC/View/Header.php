<!--HTML-->
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="CSS/MVCStyle.css">
    <title>Formations</title>
</head>

<!--Navigation Bar-->
<div class="navbar">
    <form method="post">
        <button type="submit" name="Cart" value="Cart" class="cart"><i class="cart"></i></button>
    </form>
</div>
<body>
