<!--Display of alla available formation-->
<form method="post">
    <h1>Choose a class</h1>
    <input type="submit" name="Course" value="PHP"/><br/>
    <input type="submit" name="Course" value="AJAX"/><br/>
    <input type="submit" name="Course" value="JAVA"/><br/>
</form>
